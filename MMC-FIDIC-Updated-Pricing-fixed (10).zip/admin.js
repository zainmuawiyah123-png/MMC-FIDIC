/* MMC — لوحة تحكم إدارة الطلبات (محلية بالكامل — localStorage) */
(function () {
  'use strict';

  // رمز الدخول — غيّره هنا. (حاجز محلي للعرض فقط، ليس حماية حقيقية)
  var ADMIN_PASS = '2468';
  var STORE_KEY = 'mmc_orders';
  var SESSION_KEY = 'mmc_admin_ok';

  var PLAN_LABELS = {
    pro: 'باقة المهندس',
    team: 'احترافي',
    free: 'تجربة مجانية'
  };
  var PLAN_PRICES = {
    pro: '10 د.أ شهريًا',
    team: '40 د.أ شهريًا',
    free: 'مجانية لمدة أسبوع'
  };
  // بيانات جهة التواصل (تظهر في تذييل بريد التأكيد) — عدّلها عند الحاجة
  var BRAND = {
    name: 'MMC — FIDIC Advisory',
    person: 'المهندس معاوية المدادحة',
    email: 'm.amadadha@mrc-jordan.com',
    payNumber: '+962 79 517 7640',
    payName: 'سمر زارو'
  };
  var STATUS_LABELS = {
    pending: 'بانتظار التحقق',
    verified: 'مُفعّلة',
    rejected: 'مرفوضة'
  };

  var state = {filter: 'all', search: ''};

  function $(id) { return document.getElementById(id); }

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>\"']/g, function (c) {
      return {'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[c];
    });
  }

  function fmtDate(iso) {
    try {
      var d = new Date(iso);
      if (isNaN(d.getTime())) return '—';
      return d.toLocaleString('ar', {dateStyle: 'medium', timeStyle: 'short'});
    } catch (e) { return '—'; }
  }

  function loadOrders() {
    var arr = [];
    try { arr = JSON.parse(localStorage.getItem(STORE_KEY) || '[]'); } catch (e) { arr = []; }
    if (!Array.isArray(arr)) arr = [];
    // توافقية: أعطِ معرّفًا للطلبات القديمة دون id
    var changed = false;
    arr.forEach(function (o, i) {
      if (!o.id) { o.id = 'MMC-LEGACY-' + (i + 1); changed = true; }
      if (!o.status) { o.status = 'pending'; changed = true; }
    });
    if (changed) saveOrders(arr);
    return arr;
  }

  function saveOrders(arr) {
    try { localStorage.setItem(STORE_KEY, JSON.stringify(arr)); } catch (e) {}
  }

  function setStatus(id, status) {
    var arr = loadOrders();
    arr.forEach(function (o) {
      if (o.id === id) { o.status = status; o.updatedAt = new Date().toISOString(); }
    });
    saveOrders(arr);
    render();
  }

  function deleteOrder(id) {
    if (!confirm('حذف هذا الطلب نهائيًا؟')) return;
    var arr = loadOrders().filter(function (o) { return o.id !== id; });
    saveOrders(arr);
    render();
  }

  /* ===== نموذج بريد تأكيد الطلب للعملاء ===== */
  function buildEmail(o) {
    var plan = PLAN_LABELS[o.plan] || o.plan || 'الباقة';
    var price = PLAN_PRICES[o.plan] || '';
    var st = o.status || 'pending';
    var subject, body;
    var greeting = 'الأستاذ(ة) ' + (o.name || '') + '،\nتحية طيبة،';
    var footer =
      '\n\nمع خالص التقدير،\n' +
      BRAND.person + '\n' + BRAND.name + '\n' + BRAND.email;

    if (st === 'verified') {
      subject = 'تأكيد تفعيل اشتراكك — ' + plan + ' | ' + (o.id || '');
      body =
        greeting + '\n\n' +
        'يسرّنا إبلاغك بأنه تم التحقق من دفعتك وتفعيل اشتراكك بنجاح. إليك تفاصيل الطلب:\n\n' +
        '• رقم الطلب: ' + (o.id || '—') + '\n' +
        '• الباقة: ' + plan + (price ? ' (' + price + ')' : '') + '\n' +
        '• رقم العملية: ' + (o.transactionId || '—') + '\n' +
        '• حالة الاشتراك: مُفعّل\n\n' +
        'يمكنك الآن استخدام كامل ميزات الأداة. لأي استفسار لا تتردد في الرد على هذا البريد.' +
        footer;
    } else if (st === 'rejected') {
      subject = 'بخصوص طلب اشتراكك — ' + plan + ' | ' + (o.id || '');
      body =
        greeting + '\n\n' +
        'شكرًا لطلبك الاشتراك في ' + plan + '. للأسف لم نتمكّن من التحقق من وصول المبلغ لرقم العملية التالي:\n\n' +
        '• رقم الطلب: ' + (o.id || '—') + '\n' +
        '• رقم العملية المدخل: ' + (o.transactionId || '—') + '\n\n' +
        'نرجو التأكد من إتمام التحويل إلى ' + BRAND.payName + ' (' + BRAND.payNumber + ') ثم موافاتنا برقم العملية الصحيح، وسنسعد بإكمال التفعيل فورًا.' +
        footer;
    } else {
      subject = 'استلام طلب اشتراكك — ' + plan + ' | ' + (o.id || '');
      body =
        greeting + '\n\n' +
        'شكرًا لاشتراكك معنا. لقد استلمنا طلبك وهو الآن «بانتظار التحقق». تفاصيل الطلب:\n\n' +
        '• رقم الطلب: ' + (o.id || '—') + '\n' +
        '• الباقة: ' + plan + (price ? ' (' + price + ')' : '') + '\n' +
        '• رقم العملية: ' + (o.transactionId || '—') + '\n\n' +
        'سنقوم بالتحقق من وصول المبلغ ونوافيك بتأكيد التفعيل في أقرب وقت. شكرًا لثقتك.' +
        footer;
    }
    return {subject: subject, body: body};
  }

  function emailOrder(o) {
    if (!o.email) { alert('لا يوجد بريد إلكتروني لهذا العميل.'); return; }
    var m = buildEmail(o);
    var href = 'mailto:' + encodeURIComponent(o.email) +
      '?subject=' + encodeURIComponent(m.subject) +
      '&body=' + encodeURIComponent(m.body);
    window.location.href = href;
  }

  function render() {
    var all = loadOrders();
    // KPIs
    var counts = {total: all.length, pending: 0, verified: 0, rejected: 0};
    all.forEach(function (o) { if (counts[o.status] != null) counts[o.status]++; });
    $('kTotal').textContent = counts.total;
    $('kPending').textContent = counts.pending;
    $('kVerified').textContent = counts.verified;
    $('kRejected').textContent = counts.rejected;

    // filter + search (الأحدث أولاً)
    var q = state.search.trim().toLowerCase();
    var rows = all.filter(function (o) {
      if (state.filter !== 'all' && o.status !== state.filter) return false;
      if (!q) return true;
      return [o.name, o.email, o.transactionId, o.id].some(function (v) {
        return String(v || '').toLowerCase().indexOf(q) !== -1;
      });
    }).sort(function (a, b) {
      return new Date(b.submittedAt || 0) - new Date(a.submittedAt || 0);
    });

    var body = $('ordersBody');
    body.innerHTML = '';
    $('emptyState').style.display = rows.length ? 'none' : 'block';

    rows.forEach(function (o) {
      var tr = document.createElement('tr');
      var plan = PLAN_LABELS[o.plan] || o.plan || '—';
      var st = o.status || 'pending';
      var stLabel = STATUS_LABELS[st] || st;

      tr.innerHTML =
        '<td data-l="رقم الطلب"><span class="oid">' + esc(o.id) + '</span></td>' +
        '<td data-l="العميل" class="cust"><b>' + esc(o.name) + '</b><small dir="ltr">' + esc(o.email) + '</small></td>' +
        '<td data-l="الباقة"><span class="plan-badge">' + esc(plan) + '</span></td>' +
        '<td data-l="رقم العملية"><span class="mono" dir="ltr">' + esc(o.transactionId) + '</span></td>' +
        '<td data-l="التاريخ">' + esc(fmtDate(o.submittedAt)) + '</td>' +
        '<td data-l="الحالة"><span class="status ' + st + '">' + esc(stLabel) + '</span></td>' +
        '<td data-l="إجراءات" class="rowacts-cell"></td>';

      var actCell = tr.lastChild;
      var acts = document.createElement('div');
      acts.className = 'rowacts';

      if (st !== 'verified') acts.appendChild(makeBtn('btn-ok', 'icon-check', 'تفعيل', function () { setStatus(o.id, 'verified'); }));
      if (st !== 'rejected') acts.appendChild(makeBtn('btn-bad', 'icon-x', 'رفض', function () { setStatus(o.id, 'rejected'); }));
      if (st !== 'pending') acts.appendChild(makeBtn('btn-warn', 'icon-rotate-ccw', 'إعادة للانتظار', function () { setStatus(o.id, 'pending'); }));
      acts.appendChild(makeBtn('btn-o', 'icon-mail', 'بريد التأكيد', function () { emailOrder(o); }));
      acts.appendChild(makeBtn('btn-ghost', 'icon-trash-2', 'حذف', function () { deleteOrder(o.id); }));

      actCell.appendChild(acts);
      body.appendChild(tr);
    });
  }

  function makeBtn(cls, icon, label, handler) {
    var b = document.createElement('button');
    b.className = 'btn btn-sm ' + cls;
    b.innerHTML = '<i class="' + icon + '"></i> ' + esc(label);
    b.addEventListener('click', handler);
    return b;
  }

  function exportJson() {
    var data = JSON.stringify(loadOrders(), null, 2);
    var blob = new Blob([data], {type: 'application/json'});
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = 'mmc-orders-' + new Date().toISOString().slice(0, 10) + '.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
  }

  function clearAll() {
    if (!confirm('سيتم حذف جميع الطلبات نهائيًا. متابعة؟')) return;
    saveOrders([]);
    render();
  }

  /* بوابة الدخول */
  function unlock() {
    var val = $('passInput').value.trim();
    if (val === ADMIN_PASS) {
      try { sessionStorage.setItem(SESSION_KEY, '1'); } catch (e) {}
      showPanel();
    } else {
      $('passErr').textContent = 'رمز غير صحيح، حاول مجددًا.';
      $('passInput').value = '';
      $('passInput').focus();
    }
  }

  function showPanel() {
    $('gate').style.display = 'none';
    $('panel').style.display = 'block';
    $('logoutBtn').style.display = 'inline-flex';
    render();
  }

  function logout() {
    try { sessionStorage.removeItem(SESSION_KEY); } catch (e) {}
    location.reload();
  }

  /* ربط الأحداث */
  document.addEventListener('DOMContentLoaded', function () {
    $('gateBtn').addEventListener('click', unlock);
    $('passInput').addEventListener('keydown', function (e) { if (e.key === 'Enter') unlock(); });
    $('logoutBtn').addEventListener('click', logout);
    $('refreshBtn').addEventListener('click', render);
    $('exportBtn').addEventListener('click', exportJson);
    $('clearBtn').addEventListener('click', clearAll);

    $('searchInput').addEventListener('input', function (e) { state.search = e.target.value; render(); });

    Array.prototype.forEach.call(document.querySelectorAll('#filters .fbtn'), function (btn) {
      btn.addEventListener('click', function () {
        document.querySelectorAll('#filters .fbtn').forEach(function (b) { b.classList.remove('active'); });
        btn.classList.add('active');
        state.filter = btn.getAttribute('data-f');
        render();
      });
    });

    var ok = false;
    try { ok = sessionStorage.getItem(SESSION_KEY) === '1'; } catch (e) {}
    if (ok) showPanel(); else $('passInput').focus();
  });
}());
