// MMC FIDIC — robust, self-healing offline cache service worker
const CACHE = 'mmc-fidic-v6';
const ASSETS = [
  './', './index.html', './pricing.html', './confirm.html', './admin.html', './admin.js', './reset.html', './install.html',
  './manifest.webmanifest', './icon-192.png', './icon-512.png', './apple-touch-icon.png', './og-cover.png'
];

// install: تخزين مسبق غير ذري (لا يفشل التثبيت إن تعذر جلب ملف واحد)
self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE);
    await Promise.all(ASSETS.map(async url => {
      try {
        const res = await fetch(url, { cache: 'no-cache' });
        if (res && res.ok) await cache.put(url, res.clone());
      } catch (_) { /* تجاهل أي ملف غير متوفر */ }
    }));
    await self.skipWaiting();
  })());
});

// activate: حذف كل الكاش القديم (يُزيل أي 404 مخزّن سابقًا)
self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', event => {
  const req = event.request;
  if (req.method !== 'GET') return;

  let url;
  try { url = new URL(req.url); } catch (_) { return; }
  // اترك طلبات النطاقات الخارجية (خطوط/CDN) تمر كما هي
  if (url.origin !== self.location.origin) return;

  // صفحات التنقل: الشبكة أولاً — ولا يُخزّن أي رد غير ناجح (مثل 404)
  if (req.mode === 'navigate') {
    event.respondWith((async () => {
      try {
        const res = await fetch(req);
        if (res && res.ok) {
          const cache = await caches.open(CACHE);
          cache.put(req, res.clone()).catch(() => {});
        }
        return res;
      } catch (_) {
        const cached = await caches.match(req);
        return cached || (await caches.match('./index.html')) || Response.error();
      }
    })());
    return;
  }

  // باقي الموارد: الذاكرة أولاً ثم الشبكة
  event.respondWith((async () => {
    const cached = await caches.match(req);
    if (cached) return cached;
    try {
      const res = await fetch(req);
      if (res && res.ok) {
        const cache = await caches.open(CACHE);
        cache.put(req, res.clone()).catch(() => {});
      }
      return res;
    } catch (_) {
      return (await caches.match('./index.html')) || Response.error();
    }
  })());
});

self.addEventListener('message', event => {
  if (event.data === 'mmc-skip-waiting') self.skipWaiting();
});
